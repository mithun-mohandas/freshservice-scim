# `/docs`

Design and user documents (in addition to your godoc generated documentation).

Examples:

* https://github.com/gohugoio/hugo/tree/master/docs
* https://github.com/openshift/origin/tree/master/docs
