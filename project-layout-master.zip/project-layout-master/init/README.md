# `/init`

System init (systemd, upstart, sysv) and process manager/supervisor (runit, supervisord) configs.
